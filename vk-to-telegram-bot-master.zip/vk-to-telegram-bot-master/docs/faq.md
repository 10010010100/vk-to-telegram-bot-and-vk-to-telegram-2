# FAQ

## I have set my channel url, but I have an error with it

* Make sure that you set channel name without @

## I want to set parsing from VK user profile, not from group

* For parsing VK user profile - use only id numbers(e.g. `1`), for parsing group - use `-` + id numbers(e.g. `-1`)
