# Docs for vk-to-telegram-bot

* [FAQ](./faq.md)
* [Installation](./install.md)
* [Updating](./updating.md)
* [Configuration](./config.md)
