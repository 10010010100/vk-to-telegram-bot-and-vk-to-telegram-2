<?php
require_once "vendor/autoload.php";

//Create manager
$manager = new Manager();

//Start manager
$manager->start();